-- Objekti s�ltuvussuhte tuvastamine

-- J�rgnevas harjutuses selgitama v�lja, et kuidas leida s�ltuvussuhteid ja selleks kasutada MSSQL editori.

Create Table Departments
(
	Id int primary key identity,
	Name nvarchar(50)
)
Go

Create Table Employees
(
	Id int primary key identity,
	Name nvarchar(50),
	Gender nvarchar(10),
	Deptld int foreign key references Departments(Id)
)
Go

Create procedure sp_GetEmployees
as
Begin
	select * from Employees
END
Go

Create procedure sp_GetEmplyeesandDepartment
as
Begin
	select Employees.Name as EmployeeName,
			Departments.Name as DepartmentName
	From Employees
	join Departments
	on Employees.Deptld = Departments.Id
END
Go

Create view VwDepartment
as
Select * from Departments
Go

-- S�ltuvussuhete tuvastamiseks kasuta SQL serveri editori ja sealt omakorda otsi �les View Dependencies valik.

-- N�ide: Selleks, et leida s�ltuvusuhteid Employee tabelist, tuleb teha parem klikk ja valida View Dependencies.

-- Object Dependencies aknast saab vaadata, millest Employee tabel s�ltub.

-- Objektide s�ltuvuse tuvastamine on oluline objektide muutmise ja kustutamise kontekstist. 
-- Muidu riskid funktsionaalsuse l�hkumisega.
-- N�iteks: on olemas kaks stored procedurit (sp_GetEmployees and sp_GetEmployeesandDepartments), mis s�ltuvad Employee tabelist. 
-- Kui me ei tea s�ltuvussuhetest ja kui kustutame Employee tabeli, siis m�lemad stored procedurit kukuvad koos veateatega:
-- Msg 208, Level 16, State 1, Procedure sp_GetEmployees, Line 4 Invalid object name 'Employees'. 
-- Teistest v�imalustest r��gime j�rgnevates harjutustes.
