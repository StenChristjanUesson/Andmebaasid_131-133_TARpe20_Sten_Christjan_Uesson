-- sys.dm_sql_referencing_entities

-- Selles harjutuses kirjutame, et kuidas leida d�naamilisi haldamise funktsioone.
-- 1. sys.dm_sql_referencing_entities
-- 2. sys.dm_sql_referenced_entities

-- Erinevused:
-- 1. Viitamine terviklikule ja viidatud terviklik
-- 2. Schema-seose s�ltuvused ja mitte-schema-seotuse s�ltuvused

-- See harjutus on j�tk harjutusele nr 131, et kuidas leida objektide s�ltuvust ja kasutada selleks SQL serveri editori. 

-- J�rgnev n�ide tagastab k�ik objektid, mis s�ltuvad Employee tabelist:
Select * from sys.dm_sql_referencing_entities('dbo.Employees','Object')

-- Erinevused viitamise terviklikusele ja viidatud terviklikusele:
-- S�ltuvus tekib kahe objekti vahel, kui �ks objekt ilmub nimega teise objekti salvestatud SQL -lause sisse. SQL -avaldise sees kuvatavat objekti nimetatakse viidatud olemiks ja objekti, millel on SQL -avaldis, nimetatakse viite�ksuseks.

-- Kui soovid saada viitamise terviklikust, siis kasuta SYS.DM_SQL_REFERENCING_ENTITIES d�naamilist funktsiooni.

-- Kui soovid saada viidatud terviklikuse SYS.DM_SQL_REFERENCED_ENTITIES d�naamilist funktsiooni.

-- Oletame, et meil on stored procedure ja me tahame leida k�ik objektid, millest see salvestatud protseduur s�ltub. Seda on v�imalik saavutada teise d�naamilise haldusfunktsiooni, sys.dm_sql_referenced_entities abil.

-- J�rgnev p�ring tagastab k�ik viidatud tervikud stored procedurile nimega sp_GetEmployeesandDepartments.
Select * from
sys.dm_sql_referenced_entities('dbo.sp_GetEmployeesandDepartments','Object')

-- Pane t�hele: Kui soovid m�lemat d�naamilist funktsiooni t��tamas n�ha, siis peame t�psustama schema nime. Ilma selleta v�ib mitte anda tulemust.

-- Erinevused schema s�ltuvuse ja mitte schema s�ltuvusega:
-- Schema s�ltuvus: see takistab viidatud objektide kustutamist v�i muutmist, kuni objekt on olemas.
-- N�ide: vaade, mis on loodud SCHEMABINDING-uga v�i tabel, mis on loodud ilma v��rv�tmeta.
-- Mitte schema s�ltuvusega: see ei takista viidatud objektide kustutamist v�i muutmist
