-- sp_depends

-- Objektide suhteid on v�imalik leida erinevat moodi:
-- 1. View Dependencies valikust
-- 2. SQL serveri d�naamilise haldamisfunktsiooniga
-- 3. sp_depends system stored proceduris

-- sp_depends
-- S�steemi stored procedure, mis tagastab objektide s�ltuvused
-- N�ide:
-- 1. Kui t�psustad tabelinime argumendina, siis tabelist s�ltuvad vaated ja procedureid n�idatakse
-- 2. Kui t�psustad vaate v�i procedure nime argumendina, siis n�idatakse tabeleid ja vaateid, millest t�psustatud  procedured s�ltuvad.

-- S�ntaks: Execute sp_depends 'ObjectName'

-- J�rgnev SQL skript loob tabeli ja stored procedure:

Create table Employees
(
    Id int primary key identity,
    Name nvarchar(50),
    Gender nvarchar(10)
)
Go

Create procedure sp_GetEmployees
as
Begin
    Select * from Employees
End
Go

-- Tagastab stored procedure, mis s�ltub Employees tabelist:
sp_depends 'Employees'

-- Tagastab tabeli nime ja vastava veerunime, milles stored procedure sp_GetEmployees s�ltub:
sp_depends 'sp_GetEmployees'

-- M�nikord sp_depends ei anna �igeid vastuseid. N�iteks, kustutame ja loome tabeli uuesti:

-- kustutame tabeli

Drop table Employees

-- loome tabeli

Create table Employees
(
    Id int primary key identity,
    Name nvarchar(50),
    Gender nvarchar(10)
)
Go

-- N��d t�ida j�rgnev kood leidmaks Employee tabeli s�ltuvusi:
-- sp_depends 'Employees'

-- Teame, et stored procedure sp_GetEmployees s�ltub Employees tabelist, 
-- aga sp_depends ei n�ita seda kuna tabel oli kustutatud ja uuesti loodud:
-- Object does not reference any object, and no objects reference it. 

-- sp_depends on v�hendatud variandi asukohas. See v�idakse eemaldada tulevastes SQL serveri versioonides.
